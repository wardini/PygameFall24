
glbls = {

'WIDTH' : 1280,
'HEIGHT': 768,

'VERSION' : 0.1,
'COMPATABLE_VERSIONS' : [],

'start_state' : 'IntroScreen',
'start_level' : 0,

'Full Screen' : False,

'dtrans' : {
    'a' : ('apple',10),
    'b' : ('banana',10),
    'c' : ('carrot',8),
    'C' : ('cookbook',25),
    'e' : ('coffee',4),
    'f' : ('french_fries',5),
    'g' : ('egg',4),
    'h' : ('cherries',2),
    'i' : ('pizza',20),
    'k' : ('taco',10),
    'm' : ('drumstick',8),
    'o' : ('doughnut',5),
    'p' : ('pretzel',3),
    'r' : ('ice_cream',10),
    's' : ('soda',3),
    't' : ('truck',50),
    'u' : ('sushi',3),
    'U' : ('cupcake',8),
    'w' : ('watermelon',20),
    'y' : ('strawberry',20),
    }
}
